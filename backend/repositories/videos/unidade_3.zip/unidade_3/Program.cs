﻿using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;

namespace gcgcg
{
  public class Program
  {
    static void Main(string[] args)
    {
      new Mundo();
    }
  }

}
